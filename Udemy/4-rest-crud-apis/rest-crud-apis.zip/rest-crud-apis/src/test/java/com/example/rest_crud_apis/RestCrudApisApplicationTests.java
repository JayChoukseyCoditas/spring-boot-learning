package com.example.rest_crud_apis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestCrudApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
