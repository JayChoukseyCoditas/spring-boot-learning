package com.example.rest_crud_apis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestCrudApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestCrudApisApplication.class, args);
	}

}
